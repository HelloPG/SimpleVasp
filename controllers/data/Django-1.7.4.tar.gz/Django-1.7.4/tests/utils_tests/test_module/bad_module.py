import a_package_name_that_does_not_exist  # NOQA

content = 'Bad Module'
